echo The value of x is $x
x=20                      # Now change the value of x
echo The new value of x is $x

