#include <stdio.h>
void arg_check (int, int, char *, int);
