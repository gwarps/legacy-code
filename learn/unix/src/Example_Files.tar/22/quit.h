#include <stdio.h>
void quit (char *, int); 
